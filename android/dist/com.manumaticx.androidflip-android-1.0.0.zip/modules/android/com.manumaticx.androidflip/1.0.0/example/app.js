var flip = require('de.manumaticx.androidflip');
var flipView = flip.createFlipView({
	views: views
});
